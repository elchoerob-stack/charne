@echo off
rem Puts an "RB Brand Studio" shortcut on the desktop that opens the Studio in its own window.
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$d=[Environment]::GetFolderPath('Desktop'); $s=(New-Object -ComObject WScript.Shell).CreateShortcut($d+'\RB Brand Studio.lnk');" ^
  "$e=(Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\msedge.exe' -ErrorAction SilentlyContinue).'(default)';" ^
  "if($e){$s.TargetPath=$e; $s.Arguments='--app=\"file:///%~dp0studio.html\"'; $s.IconLocation=$e+',0'} else {$s.TargetPath='%~dp0Start RB Brand Studio.cmd'};" ^
  "$s.WorkingDirectory='%~dp0'; $s.Save()"
echo.
echo Done: "RB Brand Studio" is now on your desktop.
pause
