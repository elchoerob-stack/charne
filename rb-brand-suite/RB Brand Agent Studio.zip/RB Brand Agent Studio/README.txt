RB BRAND AGENT STUDIO
=====================

Personalised client books for every seller, buyer and new owner, made from your own
listing directory. Works offline. Your listings and clients stay on this PC.

INSTALL (once)
1. Right-click the downloaded zip > Extract All. Put the folder somewhere permanent,
   such as Documents\RB Brand Agent Studio. (Don't run it from inside the zip.)
2. Double-click "Create desktop shortcut.cmd". If Windows asks, click More info > Run anyway.
3. Open the Studio from the "RB Brand Studio" shortcut on your desktop.
   Always open it the same way: your work is saved in that browser on this PC.

FIRST TIME
- My details & backup: add your name, title, cell number, email, FFC number and photo.
- Listings: add each house you are selling, with photos. Add sold houses too: they fill the
  comparable sales and recent sales in your Listing Presentations.

FOR EACH CLIENT
1. Clients > New client. Choose seller, buyer or new owner, the book language, and link the
   house (or up to 3 homes for a buyer).
2. Click the book to open it: the client's name, the house, its photos, your details and your
   sold houses are filled in for you.
3. Tap Edit to change anything else. Your edits are kept for that client.
4. Tap "Save as PDF", choose "Save as PDF", and send that PDF to the client on WhatsApp or
   email. It opens on every phone, iPhones included.

BACKUP
My details & backup > Download backup, every week. Keep it on OneDrive or Google Drive.
"Restore from a backup" brings everything back, or moves it to a new PC.

Needs: Windows 10 or 11 with Microsoft Edge (already installed on every Windows PC).
Also runs in Chrome or Edge on a Mac: open studio.html.
