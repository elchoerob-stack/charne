@echo off
rem Opens RB Brand Agent Studio in its own window (Microsoft Edge app mode), or the default browser.
start "" msedge --app="file:///%~dp0studio.html" 2>nul || start "" "%~dp0studio.html"
